import nextcord, os, random, datetime, asyncio
from nextcord.ext import commands
import json
import requests
import time
from nextcord import SlashOption
from nextcord import Embed, Activity, ActivityType
from dateutil.parser import parse
import string
from nextcord.ext import tasks

with open('config.json') as config_file:
    config = json.load(config_file)


free_cooldowns = {}

intents = nextcord.Intents.all()
bot = commands.Bot(intents=intents, help_command=None)

user_cooldowns = {}
generations = {}
generator_status = True 
premium_role_ids = config["roles"]["premium_role_ids"]
supporter_role_ids = config["roles"]["supporter_role_ids"]

@bot.event
async def on_ready():
    print(f'Logged in as {bot.user.name} ({bot.user.id})')
    send_panel.start()

class GenerationDropdown(nextcord.ui.Select):
    async def callback(self, interaction: nextcord.Interaction):
        await generate_account(interaction, generator_status)

class GenerationDropdownView(nextcord.ui.View):
    def __init__(self):
        super().__init__()

        options = [
            nextcord.SelectOption(label="2017", value="2017", emoji="⭐"),
            nextcord.SelectOption(label="2018", value="2018", emoji="⭐"),
            nextcord.SelectOption(label="2023", value="2023", emoji="🆓"),
            nextcord.SelectOption(label="2024", value="2024", emoji="🆓"),
            nextcord.SelectOption(label="Realistic", value="realistic", emoji="🆓"),
            nextcord.SelectOption(label="5 Characters", value="5_characters", emoji="⭐")
        ]

        self.add_item(GenerationDropdown(options=options, placeholder="Select a stock type"))

@tasks.loop(minutes=3)
async def send_panel():
    panel_channel = bot.get_channel(config["channels"]["panel_channel"])

    await panel_channel.purge()

    view = GenerationDropdownView()

    embed = nextcord.Embed(
        title=config["embed"]["generation_panel"]["title"], 
        description=config["embed"]["generation_panel"]["description"], 
        color=nextcord.Color.dark_gray()
    )
    embed.set_footer(text=config["embed"]["footer_text"])
    embed.set_image(url=config["embed"]["image_url"])

    view.add_item(nextcord.ui.Button(style=nextcord.ButtonStyle.primary, label="Upgrade", url="https://discord.com/channels/1231358521350688890/1231358918924570635"))
    view.add_item(nextcord.ui.Button(style=nextcord.ButtonStyle.success, label="Status", url="https://discord.com/channels/1231358521350688890/1231664848438300732"))
    view.add_item(nextcord.ui.Button(style=nextcord.ButtonStyle.danger, label="Report Bug", url="https://discord.com/channels/1231358521350688890/1231358918924570635"))

    await panel_channel.send(embed=embed, view=view)
    await bot.change_presence(activity=nextcord.Game(name=".gg/allgen"))

if not os.path.exists("generations.json"):
    with open("generations.json", "w") as file:
        json.dump({"globally_generated": 0, "user_generated": {}}, file)

with open("generations.json", "r") as file:
    generations = json.load(file)

cooldowns = {}

user_cooldowns = {}

async def generate_account(interaction, generator_status):
    global user_cooldowns, generations

    if not generator_status:
        embed = nextcord.Embed(
            title=":x: Timeout",
            description="The generator is currently offline. Please wait as we turn it on.",
            color=nextcord.Color.red()
        )
        await interaction.response.send_message(embed=embed, ephemeral=True)
        return

    log_channel = bot.get_channel(config["channels"]["log_channel"])

    current_time = datetime.datetime.now()

    user = interaction.user
    user_id = interaction.user.id

    user_roles = [role.id for role in user.roles]

    if any(role_id in premium_role_ids for role_id in user_roles):
        cooldown_duration = datetime.timedelta(seconds=5)
        stock_directories = ["premiumstock", "freestock"]
        stock_type = "Premium"
        ephemeral = True
    elif any(role_id in supporter_role_ids for role_id in user_roles):
        cooldown_duration = datetime.timedelta(seconds=30)
        stock_directories = ["freestock"]
        stock_type = "Supporter"
        ephemeral = True
    else:
        cooldown_duration = datetime.timedelta(seconds=60)
        stock_directories = ["freestock"]
        stock_type = "Free"
        ephemeral = True

    if interaction.user.id in user_cooldowns:
        elapsed_time = current_time - user_cooldowns[interaction.user.id]

        if elapsed_time < cooldown_duration:
            remaining_time = cooldown_duration - elapsed_time
            embed = nextcord.Embed(
                title="⌛ Cooldown Active",
                description=f"Please wait `{remaining_time.seconds}` seconds before generating again.",
                color=nextcord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

    user_cooldowns[interaction.user.id] = current_time

    stock_name = interaction.data['values'][0].capitalize()
    stock = interaction.data['values'][0].lower() + ".txt"

    stock_found = False
    for stock_directory in stock_directories:
        if os.path.exists(f"{stock_directory}/{stock}"):
            stock_found = True
            break

    if not stock_found:
        if stock == "2017" and stock_type != "Premium":
            embed = nextcord.Embed(
                title="🔑 Premium Required",
                description=f":x: Generating from **{stock_name}** requires premium access.",
                color=nextcord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

        else:
            embed = nextcord.Embed(
                title=":x: Out of Stock",
                description=f"Unfortunately, `{stock_name}` is currently out of stock. Please try again later.",
                color=nextcord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

    embed = nextcord.Embed(
        title=config["embed"]["processing_account"]["title"],
        description=config["embed"]["processing_account"]["description"],
        color=config["embed"]["processing_account"]["color"]
    )
    await interaction.response.send_message(embed=embed, ephemeral=ephemeral)

    with open(f"{stock_directory}/{stock}", "r") as file:
        lines = file.readlines()

    if not lines:
        if stock == "2017" and stock_type != "Premium":
            embed = nextcord.Embed(
                title="🔑 Premium Required",
                description=f":x: Generating from **{stock_name}** requires premium access.",
                color=nextcord.Color.red()
            )
            await interaction.followup.send(embed=embed, ephemeral=ephemeral)
            return

        else:
            embed = nextcord.Embed(
                title=":x: Out of Stock",
                description=f"Unfortunately, `{stock_name}` is currently out of stock. Please try again later.",
                color=nextcord.Color.red()
            )
            await interaction.followup.send(embed=embed, ephemeral=ephemeral)
            return

    username, password = random.choice(lines).strip().split(":")

    del lines[lines.index(f"{username}:{password}\n")]
    with open(f"{stock_directory}/{stock}", "w") as file:
        file.writelines(lines)

    generations["globally_generated"] += 1
    if str(user_id) not in generations["user_generated"]:
        generations["user_generated"][str(user_id)] = 0
    generations["user_generated"][str(user_id)] += 1

    with open("generations.json", "w") as file:
        json.dump(generations, file)

    time.sleep(2)

    embed = nextcord.Embed(
        title=config["embed"]["account_generation_successful"]["title"],
        color=nextcord.Color.light_gray()
    )
    embed.add_field(name="🔑 Account Details", value=f"```username: {username}\npassword: {password}```")
    embed.set_footer(text=config["embed"]["footer_text"])
    embed.set_thumbnail(url=config["embed"]["thumbnail_url_default"])

    await interaction.followup.send(embed=embed, ephemeral=ephemeral)
    await log_channel.send(f"Account generated for {interaction.user.mention} from {stock_name} stock type.")

bot.run(config["bot_token"])
