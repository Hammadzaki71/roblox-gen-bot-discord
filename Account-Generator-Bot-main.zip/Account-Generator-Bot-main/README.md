# Account Generator Bot

- With dropdowns, this took me 30 minutes to code with NO api usage.
- Don't skid & leave credits please!!

- Join https://discord.gg/altgenerator for a Roblox Alt Generator

Replace

```class GenerationDropdownView(nextcord.ui.View):
    def __init__(self):
        super().__init__()

        options = [
            nextcord.SelectOption(label="2017", value="2017", emoji="⭐"),
            nextcord.SelectOption(label="2018", value="2018", emoji="⭐"),
            nextcord.SelectOption(label="2023", value="2023", emoji="🆓"),
            nextcord.SelectOption(label="2024", value="2024", emoji="🆓"),
            nextcord.SelectOption(label="Realistic", value="realistic", emoji="🆓"),
            nextcord.SelectOption(label="5 Characters", value="5_characters", emoji="⭐")
        ]

        self.add_item(GenerationDropdown(options=options, placeholder="Select a stock type"))```
With your service names BTW
